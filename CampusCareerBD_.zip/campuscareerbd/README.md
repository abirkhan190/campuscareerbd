# CampusCareer BD (PHP + MySQL version)

Front end: HTML, CSS, JavaScript. **Back end: PHP (`api.php`) + MySQL database.**
All data (students, employers, jobs, applications, notifications) is stored in the MySQL
database `campuscareerbd`, so it is shared between every browser and device.

## Run it (XAMPP)
1. Install and open **XAMPP**. Start **Apache** and **MySQL**.
2. Copy this whole folder to `C:\xampp\htdocs\campuscareerbd`
3. Open **http://localhost/campuscareerbd/** in the browser.
   The database and all tables are created automatically on the first page load
   (XAMPP default: user `root`, empty password - change the top of `api.php` if yours differs).
4. See the data: http://localhost/phpmyadmin -> database `campuscareerbd`.
   (`database.sql` shows the schema; importing it is optional.)

## Use it from another browser / phone / laptop (same WiFi)
1. On the XAMPP laptop run `ipconfig` and note the IPv4 address (e.g. 192.168.0.105).
2. On the other device open `http://192.168.0.105/campuscareerbd/`
   (if it does not open, allow Apache through Windows Firewall).
3. Each browser has its own login, so Employer, Admin and Student can be logged in on
   different devices at the same time. A job posted by the employer appears in the
   admin's pending list after the admin page is opened/refreshed.

## Files
- `api.php` - the backend (load / save / login, talks to MySQL with PDO)
- `js/script.js` - front-end logic, calls `api.php`
- `*.html`, `css/style.css` - pages and design
- `database.sql` - table structure

## Roles
- **Student**: register/login, profile, job search with filters, Smart Match Score, Skill Gap, apply, track applications, CV builder
- **Employer**: register/login, post jobs, see applicants, change status
- **Admin** (`admin@campuscareer.bd` / `Admin@123`): approve/reject jobs, verify users, remove jobs, analytics

## Smart Match Score
Skills 55% + Location 20% + Preferred hours 15% + Class schedule 10%.

## Notes
- Passwords are stored hashed (`password_hash`) and login is checked on the server.
- "SMS notifications" are simulated (in-app alert); a real SMS gateway is not connected.
- "Verification" is a manual admin toggle.
- The "who is logged in" session is kept in the browser, so this is a prototype, not a hardened production system.
- This version needs PHP, so it does not run on Netlify (static hosting).
